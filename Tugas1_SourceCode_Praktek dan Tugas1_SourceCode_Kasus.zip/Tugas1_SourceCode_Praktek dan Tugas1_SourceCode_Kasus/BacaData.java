/*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
import java.util.Scanner;
/* contoh membaca integer menggunakan Class Scanner*/
 public class BacaData {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Kamus */
    int a;
    Scanner masukan;
/* Program */
    System.out.print ("Contoh membaca dan menulis, ketik  nilai integer: \n");
    masukan = new Scanner(System.in);
    a = masukan.nextInt(); /* coba ketik :
masukan.nextInt();
Apa akibatnya ?*/
System.out.print ("Nilai yang dibaca : "+ a);
}
 }
