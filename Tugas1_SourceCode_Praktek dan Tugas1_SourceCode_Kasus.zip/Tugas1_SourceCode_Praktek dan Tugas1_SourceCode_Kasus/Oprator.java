/*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
/* Contoh pengoperasian variabel bertype dasar */
public class Oprator {
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* Kamus */
    boolean Bool1, Bool2, TF;
    int i,j, hsl;
    float x,y,res;
    /* algoritma */
  
    Bool1 = true; Bool2 = false;
    TF = Bool1 && Bool2 ; /* Boolean AND */
    System.out.print ("-----------------Operator Logika -------------");
    System.out.print ("\nBoleean AND = "+ TF);
    TF = Bool1 || Bool2 ; /* Boolean OR */
    System.out.print ("\nB OR = "+ TF);
    TF = ! Bool1 ; /* NOT */
    System.out.print ("\n NOT = "+ TF);
    TF = Bool1 ^Bool2; /* XOR */
    System.out.print ("\nBoleean XOR = "+ TF);
     /* operasi numerik */
    i = 5; j = 2 ;
    System.out.print ("\n----------------- Operasi Numerik 1 (i dan j) -------------");
    hsl = i+j;
    System.out.print ("\nhasil penjumlahan = "+ hsl);
    hsl = i - j;
    System.out.print ("\nhasil pengurangan = "+ hsl);
    hsl = i / j;
    System.out.print ("\nhasil pembagian = "+ hsl);
    hsl = i * j;
    System.out.print ("\nhasil perkalian = "+ hsl);
    hsl = i /j ; /* pembagian bulat */
    System.out.print ("\nhasil pembagian bulat = "+ hsl);
    hsl = i%j ; /* sisa modulo */
    System.out.print ("\nhasil modulo = "+ hsl);
    /* operasi numerik */
    System.out.print ("\n----------------- Operasi Numerik 2 (x dan y) -------------");
    x = 5 ; y = 5 ;
    res = x + y;
    System.out.print ("\nhasil penjumlahannya = "+ res);
    res = x - y;
    System.out.print ("\nhasil pengurangannya = "+ res);
    res = x / y;
    System.out.print ("\nhasil pembagian = "+ res);
    res = x * y;
    System.out.print ("\nhasil perkalian = "+ res);
    /* operasi relasional numerik */
    System.out.print ("\n----------------- Operasi Relasional Numerik (i dan j)-------------");
    TF = (i==j);
    System.out.print ("\nhasil i==j : "+ TF);
    TF = (i!=j);
    System.out.print ("\nhasil i!=j : "+ TF);
    TF = (i < j);
    System.out.print ("\nhasil i < j : "+ TF);
    TF = (i > j);
    System.out.print ("\nhasil i > j : "+ TF);
    TF = (i <= j);
    System.out.print ("\nhasil i <=j : "+ TF);
    TF = (i >= j);
    System.out.print ("\nhasil i >=j : "+ TF);
    /* operasi relasional numerik */
    System.out.print ("\n----------------- Operasi Relasional Numerik (x dan y)-------------");
    TF = (x != y);
    System.out.print ("\nhasil x != y : "+ TF);
    TF = (x < y);
    System.out.print ("\nhasil x < y : "+ TF);
    TF = (x > y);
    System.out.print ("\nhasil x > y : "+ TF);
    TF = (x <= y);
    System.out.print ("\nhasil x <= y : "+ TF);
    TF = (x >= y);
    System.out.print ("\nhasil x >= y : "+ TF);
     }
    }