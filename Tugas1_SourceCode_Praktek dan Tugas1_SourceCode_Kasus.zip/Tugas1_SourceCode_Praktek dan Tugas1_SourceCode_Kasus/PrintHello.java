/*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
public class PrintHello {
    /**
    * @param args
    */
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* menuliskan hello ke layar */
    System.out.print("Hello");
    /* menuliskan hello dan ganti baris*/
    System.out.print("\nHello ");
    /* menuliskan hello dan ganti baris*/
    System.out.println("World");
    System.out.println("Welcome");
    }
}
