 /*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
 /* Effek dari operator ++ */
 public class Incr {
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* Kamus */
    int i, j;
    /* Program */
    i = 3;
    j = i++;
    System.out.println ("Nilai i : " + (++i) + "\nNilai j : " + j);
    }
    }
