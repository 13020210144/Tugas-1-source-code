/*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
public class Asgdll {
    /**
    * @param args
    */
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* Kamus */
    float f= 20.0f;
    double fll;
    /* Algoritma */
    fll=10.0f;
    System.out.println ("f : "+f+ "\nf11: "+fll);
    }
}
