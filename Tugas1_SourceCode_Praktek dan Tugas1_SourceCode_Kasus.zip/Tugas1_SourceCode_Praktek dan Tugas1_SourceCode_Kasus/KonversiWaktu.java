/*
 * Tanggal 10 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */

import java.util.Scanner;

public class KonversiWaktu {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            System.out.print("Masukkan total detik: ");
            int totalDetik = input.nextInt();

            int detikSekarang = totalDetik % 60;
            int totalMenit = totalDetik / 60;
            int menitSekarang = totalMenit % 60;
            int totalJam = totalMenit / 60;
            int jamSekarang = totalJam % 24;

            System.out.printf("%d:%02d:%02d\n", jamSekarang, menitSekarang, detikSekarang);
        }
    }
}

